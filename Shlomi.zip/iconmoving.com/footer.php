    <div id="wraper-footer">

        <div id="footer-top">

            <div class="container">

                <div id="column1" class="column">

                    <div class="thumn"><img src="images/moviebox.png" /></div>

                    <div class="content-column">

                        <h2>Moving Boxes</h2>

                        <p class="cont">Everything you need to know about moving boxes to make your move with New Horizon easy and stress-free

                        </p>

                        <!-- <a class="more">Learn more</a> -->

                    </div>

                </div>

                <div id="column2" class="column"><a href="coupons.php">

                    <div class="thumn"><img src="images/discount.png" /></div>

                    <div class="content-column">

                        <h2>Discount Coupons</h2>

                        <p class="cont">Take advantage of our exclusive moving and storage discount coupons and save money on your relocation today
                        </p>

                        <!-- <a class="more">Learn more</a> -->



                    </div>
					</a>
                </div>

                <div id="column3" class="column">

                    <div class="thumn"><img src="images/callback.png" /></div>

                    <div class="content-column">

                        <h2>Instant Callback</h2>

                        <p class="cont">Want information or assistance right now? We'll call you! Simply complete the free moving quote form 

                        </p>

                        <!-- <a class="more">Learn more</a> -->



                    </div>

                </div>

                <div id="column4" class="column">

                    <div class="thumn"><img src="images/testimonial.png" /></div>

                    <div class="content-column">

                        <h2>Testimonials</h2>

                        <p class="cont">Read comments of our Boca Raton, Delray Beach, Deerfield Beach and Maimi Florida customers who are happy to have used our services

                        </p>

                        <!-- <a class="more">Learn more</a> -->

                    </div>

                </div>

            </div>s


	<p align="center">DOT Number 1256110, MC 492093, IM 2373, MV1095</p>
    
    <p align="center">Areas of Moving Service in Florida: </p>
    	<p align="center"><a href="boca_raton_movers.php" target="_blank">Boca Raton Movers</a> &nbsp; &nbsp; &nbsp; 
<a href="boynton_beach_movers.php" target="_blank">Boynton Beach Movers</a> &nbsp; &nbsp; &nbsp; 
<a href="delray_beach_movers.php" target="_blank">Delray Beach Movers</a> &nbsp; &nbsp; &nbsp; 
<a href="fort_lauderdale_movers.php" target="_blank">Fort Lauderdale Movers</a> &nbsp; &nbsp; &nbsp; 
<a href="jupiter_movers.php" target="_blank">Jupiter Movers</a> &nbsp; &nbsp; &nbsp; <br/>
<a href="miami_movers.php" target="_blank">Miami Movers</a> &nbsp; &nbsp; &nbsp; 
<a href="palm_beach_garden_movers.php" target="_blank">Palm Beach Garden Movers</a> &nbsp; &nbsp; &nbsp; 
<a href="wellington_movers.php" target="_blank">Wellington Movers</a> &nbsp; &nbsp; &nbsp; 
<a href="west_palm_beach_movers.php" target="_blank">West Palm Beach Movers</a>

</p>
    
    <p align="center"><img src="images/credit.jpg" /></p>
        </div><!-- end # footer-top -->

        <div id="footer-bottom">

            <div class="container">
            
     

                <div id="copy-right">

                <p>&copy; Copyright 2014, <span>Icon Moving</span>, All Rights Reserved.</p>

                <ul>

                    <li><a href="#">News</a></li>

                    <li>/</li>  

                    <li><a href="sitemap.php">Sitemap</a></li>

                    <li>/</li>  

                    <li><a href="privacy.php">Privacy</a></li> 

                </ul>

                </div>
  
            </div>

        </div><!-- end # footer-bottom -->

    </div><!-- end # wraper-footer -->

</div>

</body>

</html>